#include <cstdlib>
#include <iostream>

using namespace std;
#define ARCHIVO_TXT C:/Users/Sala5/archivo.txt//respaldo de datos
int main(int argc, char *argv[])/* cin,cout,endl*/
{
    cout<<"HOLA MUNDO c++ Curso Programaci\'on Avanzada"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
